from django.shortcuts import render
from .models import Tweet
from .forms import TweetForm, UserRegisterationForm
from .forms import TweetForm 
from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login



# Create your views here.
def index(request):
    return render(request, 'index.html') 

def tweet_list(request):
    tweets = Tweet.objects.all().order_by('-created_at')
    return render(request, 'tweet_list.html', {'tweets': tweets})
@login_required
def tweet_create(request):                  #creating tweet
    if request.method == "POST":
        form = TweetForm(request.POST, request.FILES)
        if form.is_valid():
            tweet = form.save(commit=False)
            tweet.user = request.user
            tweet.save()
            return redirect('tweet_list')

    else:
        form = TweetForm()
    return render (request, 'tweet_form.html', {'form': form})

@login_required
def tweet_edit(request, id):          #editing tweet
    tweet = get_object_or_404(Tweet, pk = id, user = request.user)
    if request.method == 'POST':
        form = TweetForm(request.POST, request.FILES, instance=tweet)
        if form.is_valid():
            tweet = form.save(commit=False)
            tweet.user = request.user
            tweet.save()
            return redirect('tweet_list')

    else:
        form = TweetForm(instance=tweet)
    return render (request, 'tweet_form.html', {'form': form})

#deleting tweet

@login_required
def tweet_delete(request, id):
    tweet = get_object_or_404(Tweet, pk=id, user=request.user)
    if request.method == 'POST':
        tweet.delete()
        return redirect('tweet_list')
    return render(request, 'tweet_confirm_delete.html', {'tweet': tweet})

def registration(request):
    if request.method == 'POST':
        form = UserRegisterationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('tweet_list')
    else:
        form = UserRegisterationForm()

    return render(request, 'registration/registration.html', {'form': form})








